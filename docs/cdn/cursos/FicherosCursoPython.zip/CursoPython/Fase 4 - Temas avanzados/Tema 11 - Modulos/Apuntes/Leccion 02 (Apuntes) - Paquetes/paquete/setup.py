from setuptools import setup, find_packages

setup(
	name="paquete",
	version="0.1",
	description="Este es un paquete de jemplo",
	author="Hector Costa",
	author_email="yo@hcosta.info",
	url="http://hcosta.info",
    packages=find_packages(),
    scripts=[]
)