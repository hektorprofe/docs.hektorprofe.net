from saludos import Saludo

s = Saludo()